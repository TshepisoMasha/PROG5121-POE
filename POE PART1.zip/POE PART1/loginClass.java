/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepart1;

import java.util.Scanner;

/**
 *
 * @author TshepisoM
 */
class loginClass {
      
    public void login(Scanner input) {
        // requires user to enter password and username that they have registered with to login
        System.out.print("Enter username: ");
        String loginUser = input.nextLine();
        
        System.out.print("Enter password: ");
        String loginPass = input.nextLine();
        
        boolean status = loginUser(loginUser, loginPass);
        System.out.println(returnLoginStatus(status));
    }
    
    // data that is stired in the variable password and userName will be used for login
    public boolean loginUser(String username, String password) {
        return username.equals(registrationClass.userName) && password.equals(registrationClass.password);
    }
    
      
    public String returnLoginStatus(boolean loginStatus) {
        if(loginStatus) {//if the password and username is correct it will greet the user by their first and last name which were captured in the registration phase
            return "Welcome " + registrationClass.firstName + ", " + registrationClass.lastName + " it is great to see you again.";
        } else {//if incorrect the user has the option to try again or register
            return "Username or password incorrect, please try again."
                    + " Or user may not exist. Please register";
        }
    }
} 
    
    


    

