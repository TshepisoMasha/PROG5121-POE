/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepart1;

import java.util.Scanner;

/**
 *
 * @author TshepisoM 
 */
class registrationClass {
  // Static so loginClass can access the data stored in the variables
  // Using String as the data type 
   public static String firstName = "";
   public static String lastName = "";
   public static String userName = "";
   public static String password = "";
   public static String cellNumber = "";
    //overload methods for JUNIT TESTS


  // addition of methods for JUint
  public boolean checkUserName(String username) {
      return username.length() <= 5 && username.contains("_");
 } 
 public boolean checkPasswordComplexity(String password) {
     boolean hasUpper = false, hasDigit = false, hasSpecial = false;
     String special = "~!`@#$%^&*()_-+=/*?.><,:;[]{}|\"\\";
     if(password.length() < 8) return false;
      for(int i = 0; i < password.length(); i++) {
          char c = password.charAt(i);
        if(Character.isUpperCase(c)) hasUpper = true;
         if(Character.isDigit(c)) hasDigit = true;
         if(special.indexOf(c) >= 0) hasSpecial = true;
      }
      return hasUpper && hasDigit && hasSpecial;
  }
  
 public boolean checkCellPhoneNumber(String fullNum) {
     return fullNum.startsWith("+") && fullNum.length() >= 10 && fullNum.length() <= 13;
 }

 


    public void registration(Scanner input) {
        
    // The loop will continue to run until the user provides their first name 
    do { //start of loop
        // Asking user for their first and last name which will be used in the login once registration is complete
        System.out.print("Enter your first name: ");
        firstName = input.nextLine();
        if (firstName.isBlank()) {
            System.out.println("First name cannot be empty. Please try again.");
        }
    } while (firstName.isBlank()); //end of loop

    //The loop will continue to run until the user provides their last name 
    do { //start of loop
        System.out.print("Enter your last name: ");
        lastName = input.nextLine().trim();
        if (lastName.isBlank()) {
            System.out.println("Last name cannot be empty. Please try again.");
        }
    } while (lastName.isBlank()); //end of loop

        //outputing conditions to users 
        System.out.println(" ");
        System.out.println("Creating username ");
        System.out.println("-Username must contain an underscore '_'.");
        System.out.println("-Username must be no more than 5 characters.");
        checkUserName(input);
        
        System.out.println(" ");
        System.out.println("-Creating password");
        System.out.println("-Password must be no more than 8 characters.");
        System.out.println("-Password must contain a capital letter.");
        System.out.println("-Password must contain a number.");
        System.out.println("-checkPasswordComplexity(input);Password must contain a special character, eg.!@#$%&*");
        checkPasswordComplexity(input);
        
        System.out.println(" ");
        System.out.println("Creatin cellphone number ");
        System.out.println("-Cellphone number must contain an international code (+..).");
        System.out.println("-Digits after the international code must not be more than 10 digits ");
        checkCellPhoneNumber(input);
        
        System.out.println(registerUser());
    }

    
    public boolean checkUserName(Scanner input) {
       //creating a username
       String userName;
       //if the user does not follow the contions when creating a username, the loop will continue to run until the user enters the correct username1
        do { // start of loop
            System.out.print("Enter username: ");
            userName = input.nextLine();
            
            
            if(userName.contains("_") && userName.length() <=5) { // username conditions 
                System.out.println("Username successfully captured.");
                return true;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        } while(true);//end of loop
    }
    

   
    public static boolean checkPasswordComplexity(Scanner input) {
        String password;
        do {
            System.out.print("Enter password: ");
            password = input.nextLine();
            //password conditions
            boolean hasUpperCase = false;
            boolean hasNumber = false;
            boolean hasSpecial = false;
            String specialCharacters = "~!`@#$%^&*()_-+=/*?.><,:;][}{\'";
            for(int i = 0; i<password.length(); i++){
                char characters = password.charAt(i);
                if(Character.isUpperCase(characters)){
                    hasUpperCase = true;
            }
            if(Character.isDigit(characters)){
               hasNumber = true;
            }
            if(specialCharacters.indexOf(characters) >=0){
                 hasSpecial = true;
            }
      }
            if(password.length() >= 8 && hasUpperCase && hasNumber && hasSpecial){
                System.out.println("Password successfully captured.");
                return true;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        } while(true);
    }
    
    public static boolean checkCellPhoneNumber(Scanner input) {
          String cellNumber;
          String interDigitalCode;
        do {//start of loop
            System.out.print("Enter international digit code: ");
            interDigitalCode = input.nextLine();
            System.out.print("Enter cellphone number: " + interDigitalCode);
            cellNumber = input.nextLine();
            
            String fullNum = interDigitalCode + cellNumber;
            
            if(fullNum.startsWith("+") && cellNumber.length() <=10) { //digits shhould not be more than 10 digits after the international code
                System.out.println("Cell number successfully captured.");
                return true;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        } while(true); //end of loop
    }
    
    public String registerUser() {
        return "User has been registered successfully."; //when the user has entered correct information according to their requirements
    }

}
    
    




   

  
    
    

