/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart1;

/**
 *
 * @author LuckyJ
 */
import static java.lang.Math.log;
import java.util.Scanner;
public class PoePart1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        registrationClass reg = new registrationClass();
        loginClass login = new loginClass();
        
        
        boolean running = true;
        boolean isregistered = false; 
        
//user options to choose from according to the user's interest
        while(running) { //strat of loop
            System.out.println("WELCOME");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            String choice = input.nextLine();

            switch(choice) {
                case "1":
                    System.out.println("STARTING THE REGISTRATION PROCESS...");
                    reg.registration(input);
                    isregistered = true;
                    break;
                    
                case "2":
                        System.out.println("LOGIN");
                        login.login(input);
                        break;
                    
                case "3":
                    System.out.println("PROGRAM EXITED");
                    running = false;
                    break;
                    
                default:
                    System.out.println("Invalid option. Please enter 1, 2, or 3.");
            }
        }// end of loop
        input.close();
    }
}
    

