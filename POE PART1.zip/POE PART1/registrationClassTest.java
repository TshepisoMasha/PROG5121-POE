/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poepart1;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author LuckyJ
 */
public class registrationClassTest {
  
    registrationClass reg = new registrationClass();
    
    @Test
    public void testUsernameCorrectlyFormatted() {
        // Test valid username
        assertTrue(reg.checkUserName("kyl_1"));
    }
    
    @Test
    public void testUsernameIncorrectlyFormatted() {
        // Test invalid - no underscore
        assertFalse(reg.checkUserName("kyle!!!!!!!"));
    }
    
    @Test
    public void testPasswordMeetsComplexity() {
        // Test valid password: 8+ chars, capital, number, special
        assertTrue(reg.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexity() {
        // Test invalid - no special char
        assertFalse(reg.checkPasswordComplexity("password"));
    }
    
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        // Test valid SA number
        assertTrue(reg.checkCellPhoneNumber("+27838968976"));
    }
    
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        // Test invalid - no + or too long
        assertFalse(reg.checkCellPhoneNumber("08966553"));
    }
    
    @Test
    public void testLoginSuccessful() {
        // Setup: register first
        registrationClass.userName = "kyl_1";
        registrationClass.password = "Ch&&sec@ke99!";
        registrationClass.firstName = "Kyle";
        registrationClass.lastName = "Smith";
        
        loginClass login = new loginClass();
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }
    
    @Test
    public void testLoginFailed() {
        registrationClass.userName = "kyl_1";
        registrationClass.password = "Ch&&sec@ke99!";
        
        loginClass login = new loginClass();
        assertFalse(login.loginUser("wrong", "wrong"));
    }
}

